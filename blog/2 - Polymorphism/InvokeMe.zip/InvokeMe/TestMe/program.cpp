#import "..\\..\\InvokeMe\\Debug\\InvokeMe.dll" raw_interfaces_only named_guids no_namespace

#include <atlbase.h>

#include <iostream>

//Sample provided by Fabio Galuppo

HRESULT Selector(CComPtr<IDispatch>& id, const CComBSTR& value, CComBSTR& result)
{
	CComVariant vValue(value), vResult;
	HRESULT hr = id.Invoke1(OLESTR("M"), &vValue, &vResult);
	if(SUCCEEDED(hr)) result = vResult.bstrVal;
	return hr;
}

int main(int argc, char* argv[])
{
	CoInitialize(NULL);
	{
	HRESULT hr = E_FAIL;

	CComPtr<IDispatch> x, y;	

	auto m = [](CComPtr<IDispatch>& id, const CComBSTR& value)
	{ 
		CComBSTR result;
		USES_CONVERSION;
		HRESULT hr = Selector(id, value, result);
		std::cout << OLE2CA(value) << " -> " << (SUCCEEDED(hr) ? OLE2CA(result) : "") << std::endl;
	};
	
	hr = x.CoCreateInstance(CLSID_XType, NULL, CLSCTX_ALL);	
	if(SUCCEEDED(hr))
		m(x, CComBSTR("Hello"));

	hr = y.CoCreateInstance(CLSID_YType, NULL, CLSCTX_ALL);	
	if(SUCCEEDED(hr))
		m(y, CComBSTR("World"));

	CComPtr<IDispatch> z;
	z.CoCreateInstance(OLESTR("Shell.Explorer"), NULL, CLSCTX_ALL);
	if(SUCCEEDED(hr))
		m(z, CComBSTR("Something"));
	}
	CoUninitialize();

	std::cin.get();
}