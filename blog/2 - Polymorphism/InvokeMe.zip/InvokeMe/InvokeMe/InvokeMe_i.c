

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 7.00.0555 */
/* at Sat Jan 14 21:18:57 2012
 */
/* Compiler settings for InvokeMe.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 7.00.0555 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_IXType,0x75FDB56F,0xCCC9,0x4C52,0xBC,0xC2,0xB1,0xCA,0x77,0xCE,0x68,0x11);


MIDL_DEFINE_GUID(IID, IID_IYType,0x7EEC8FCD,0xA0F6,0x452E,0x8E,0x24,0xB1,0x45,0x38,0xB2,0xB8,0x0A);


MIDL_DEFINE_GUID(IID, LIBID_InvokeMeLib,0xB3A961FB,0x83CE,0x44BE,0x93,0xF2,0xF7,0xF6,0x73,0x1A,0x19,0xA9);


MIDL_DEFINE_GUID(CLSID, CLSID_XType,0xBCA3F660,0x2065,0x4DD6,0x8C,0x03,0x30,0x12,0x02,0x5A,0x15,0x85);


MIDL_DEFINE_GUID(CLSID, CLSID_YType,0x0F8D641B,0x516D,0x47CC,0x88,0x1E,0xAF,0x22,0x20,0xA5,0xAC,0x81);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



