//Sample provided by Fabio Galuppo

#include "stdafx.h"
#include "XType.h"

STDMETHODIMP CXType::M(BSTR value, BSTR* result)
{
	CComBSTR c(value);

	HRESULT hr = c.ToUpper();
	if(SUCCEEDED(hr))
	{
		*result = c;
		return S_OK;
	}

	return hr;
}
