

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 7.00.0555 */
/* at Sat Jan 14 21:18:57 2012
 */
/* Compiler settings for InvokeMe.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 7.00.0555 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __InvokeMe_i_h__
#define __InvokeMe_i_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IXType_FWD_DEFINED__
#define __IXType_FWD_DEFINED__
typedef interface IXType IXType;
#endif 	/* __IXType_FWD_DEFINED__ */


#ifndef __IYType_FWD_DEFINED__
#define __IYType_FWD_DEFINED__
typedef interface IYType IYType;
#endif 	/* __IYType_FWD_DEFINED__ */


#ifndef __XType_FWD_DEFINED__
#define __XType_FWD_DEFINED__

#ifdef __cplusplus
typedef class XType XType;
#else
typedef struct XType XType;
#endif /* __cplusplus */

#endif 	/* __XType_FWD_DEFINED__ */


#ifndef __YType_FWD_DEFINED__
#define __YType_FWD_DEFINED__

#ifdef __cplusplus
typedef class YType YType;
#else
typedef struct YType YType;
#endif /* __cplusplus */

#endif 	/* __YType_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IXType_INTERFACE_DEFINED__
#define __IXType_INTERFACE_DEFINED__

/* interface IXType */
/* [unique][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IXType;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("75FDB56F-CCC9-4C52-BCC2-B1CA77CE6811")
    IXType : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE M( 
            /* [in] */ BSTR value,
            /* [retval][out] */ BSTR *result) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IXTypeVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IXType * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IXType * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IXType * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IXType * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IXType * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IXType * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IXType * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *M )( 
            IXType * This,
            /* [in] */ BSTR value,
            /* [retval][out] */ BSTR *result);
        
        END_INTERFACE
    } IXTypeVtbl;

    interface IXType
    {
        CONST_VTBL struct IXTypeVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IXType_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IXType_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IXType_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IXType_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IXType_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IXType_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IXType_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IXType_M(This,value,result)	\
    ( (This)->lpVtbl -> M(This,value,result) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IXType_INTERFACE_DEFINED__ */


#ifndef __IYType_INTERFACE_DEFINED__
#define __IYType_INTERFACE_DEFINED__

/* interface IYType */
/* [unique][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IYType;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("7EEC8FCD-A0F6-452E-8E24-B14538B2B80A")
    IYType : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE M( 
            /* [in] */ BSTR value,
            /* [retval][out] */ BSTR *result) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IYTypeVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IYType * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IYType * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IYType * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IYType * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IYType * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IYType * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IYType * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *M )( 
            IYType * This,
            /* [in] */ BSTR value,
            /* [retval][out] */ BSTR *result);
        
        END_INTERFACE
    } IYTypeVtbl;

    interface IYType
    {
        CONST_VTBL struct IYTypeVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IYType_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IYType_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IYType_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IYType_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IYType_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IYType_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IYType_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IYType_M(This,value,result)	\
    ( (This)->lpVtbl -> M(This,value,result) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IYType_INTERFACE_DEFINED__ */



#ifndef __InvokeMeLib_LIBRARY_DEFINED__
#define __InvokeMeLib_LIBRARY_DEFINED__

/* library InvokeMeLib */
/* [version][uuid] */ 


EXTERN_C const IID LIBID_InvokeMeLib;

EXTERN_C const CLSID CLSID_XType;

#ifdef __cplusplus

class DECLSPEC_UUID("BCA3F660-2065-4DD6-8C03-3012025A1585")
XType;
#endif

EXTERN_C const CLSID CLSID_YType;

#ifdef __cplusplus

class DECLSPEC_UUID("0F8D641B-516D-47CC-881E-AF2220A5AC81")
YType;
#endif
#endif /* __InvokeMeLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


