//Sample provided by Fabio Galuppo

#include "stdafx.h"
#include "YType.h"

STDMETHODIMP CYType::M(BSTR value, BSTR* result)
{
	CComBSTR c(value);

	USES_CONVERSION;

	char* x = OLE2A(c);	
	strrev(x);	
	*result = CComBSTR(x);
	
	return S_OK;
}
