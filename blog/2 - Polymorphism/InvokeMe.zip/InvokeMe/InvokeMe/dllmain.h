// dllmain.h : Declaration of module class.

class CInvokeMeModule : public ATL::CAtlDllModuleT< CInvokeMeModule >
{
public :
	DECLARE_LIBID(LIBID_InvokeMeLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_INVOKEME, "{59E2CA39-CEC2-44E5-B496-42F00DC961F3}")
};

extern class CInvokeMeModule _AtlModule;
